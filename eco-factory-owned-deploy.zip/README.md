# Eco Factory Owned Rebuild

This directory is the owned replacement path for the current Eco Factory runtime.

It is designed to remove the production dependency on the old third-party GitLab
images while keeping the existing PostgreSQL schema and frontend API contract.

## Structure

```text
backend/       New API source
frontend/      Static frontend image source
ops/           Compose and deployment templates
```

## Current Status

- Backend source scaffold exists and targets the existing `eco_factory` schema.
- Frontend image source should be populated from the current verified deployed
  frontend until a clean frontend rewrite is completed.
- Production must not be switched until staging passes smoke tests.

## Local Backend

```bash
cd backend
npm install
npm run dev
```

Required environment variables are documented in `ops/env.example`.

